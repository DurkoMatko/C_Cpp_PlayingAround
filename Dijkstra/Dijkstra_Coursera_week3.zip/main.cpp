#include <iostream>
#include "graph.cpp"

using namespace std;

int main()
{
    graph g  = graph(9,0.44,1,10);

    pair<int,vector<int> > dijkstraPathResult = g.shortestPath(3,0);

    cout << "Shortest path from path_size is " <<  dijkstraPathResult.first<< endl << "Steps are following: " << endl;

    for(int i=dijkstraPathResult.second.size()-1;i>=0;i--){
        cout << dijkstraPathResult.second.at(i);
    }
    return 0;
}
